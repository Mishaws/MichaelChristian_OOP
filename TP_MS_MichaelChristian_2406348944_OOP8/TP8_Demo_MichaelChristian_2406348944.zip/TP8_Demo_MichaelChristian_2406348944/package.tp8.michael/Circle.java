package com.tp8.michael;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.Color;

public class Circle extends Shape {

    public Circle() {
        super();
        this.type = "Circle";
    }

    @Override
    public void render(ShapeRenderer shapeRenderer) {
        shapeRenderer.setColor(Color.BLUE); 
        shapeRenderer.circle(position.x, position.y, size / 2);
    }
}