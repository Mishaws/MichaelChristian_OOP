package com.tp8.michael;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.Color;

public class Square extends Shape {

    public Square() {
        super();
        this.type = "Square";
    }

    @Override
    public void render(ShapeRenderer shapeRenderer) {
        shapeRenderer.setColor(Color.RED); 
        shapeRenderer.rect(position.x - size / 2, position.y - size / 2, size, size);
    }
}